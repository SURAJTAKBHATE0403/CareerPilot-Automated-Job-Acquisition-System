import os
import time
import random
import requests
import re
from datetime import datetime
from dotenv import load_dotenv
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys 
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

# 1. Load Configuration from .env file
load_dotenv()
L_EMAIL = os.getenv('LINKEDIN_EMAIL')
L_PASS = os.getenv('LINKEDIN_PASSWORD')
TELEGRAM_TOKEN = os.getenv('TELEGRAM_TOKEN')
TELEGRAM_CHAT_ID = os.getenv('TELEGRAM_CHAT_ID')

# List of job titles the bot will apply to
# Updated Target Roles (Java Backend + Frontend/UI + Full Stack)
TARGET_ROLES = [
    # --- Backend & Java Roles ---
    "Java Developer", "Junior Java Developer", "Java Backend Developer", 
    "Core Java Developer", "Java Developer Fresher", "Java API Developer",
    "Java Backend Engineer", "Spring Boot Developer", "Spring Boot Developer Fresher",
    "Hibernate Developer", "Microservices Developer", "Java Spring Boot Developer",
    
    # --- Frontend & UI Roles (Based on your HTML5/CSS3 skills) ---
    "Frontend Developer", "Junior Frontend Developer", "UI Developer Fresher", 
    "Web Developer", "Junior Web Developer", "Web Developer Fresher", 
    "Frontend Developer HTML CSS", "Associate Frontend Engineer", "UI Designer Fresher",
    
    # --- Full Stack Roles ---
    "Java Full Stack Developer","Full-stack Developer", "Back End Developer","Software Development Engineer", "Full Stack Developer Fresher", "Junior Full Stack Developer",
    "Full Stack Java Developer", "Associate Software Engineer", "Software Engineer Fresher","Softwere developer enginner",
    
    # --- Database & Trainee Roles ---
    "SQL Developer", "MySQL Developer", "Trainee Software Engineer", 
    "Software Developer Trainee", "Graduate Engineer Trainee", "Entry Level Java Developer"
]

DAILY_LIMIT = 25
applied_count = 0

# Browser setup
options = webdriver.ChromeOptions()
options.add_argument("--start-maximized")
options.add_experimental_option('excludeSwitches', ['enable-logging'])
options.add_argument('--log-level=3')
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

def human_like_scroll(duration_seconds):
    """Simulates human behavior by scrolling randomly during breaks"""
    print(f"🕵️ Human simulation: Scrolling for {duration_seconds//60} minutes...")
    end_time = time.time() + duration_seconds
    while time.time() < end_time:
        scroll_amount = random.randint(200, 700)
        direction = random.choice([scroll_amount, -scroll_amount])
        driver.execute_script(f"window.scrollBy(0, {direction});")
        time.sleep(random.randint(3, 8))

def send_telegram_msg(company, role, count):
    """Sends a notification to your Telegram bot after a successful application"""
    try:
        msg = f" *Job Applied! ({count}/{DAILY_LIMIT})*\n\n *Company:* {company}\n *Role:* {role}\n CareerPilot is working!"
        url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
        payload = {"chat_id": TELEGRAM_CHAT_ID, "text": msg, "parse_mode": "Markdown"}
        requests.post(url, data=payload)
    except: pass

def auto_login():
    """Handles LinkedIn login process"""
    try:
        driver.get("https://www.linkedin.com/login")
        time.sleep(2)
        driver.find_element(By.ID, "username").send_keys(L_EMAIL)
        driver.find_element(By.ID, "password").send_keys(L_PASS)
        driver.find_element(By.ID, "password").submit()
        print("Login successful! Waiting 30s for security checks...")
        time.sleep(30) 
    except Exception as e:
        print(f" Login Error: {e}")

def fill_form():
    """Handles Experience Dropdowns (0 years/0 months) and Other Questions"""
    try:
        # 1. Handle Dropdowns (Experience, Years, Months)
        dropdowns = driver.find_elements(By.TAG_NAME, "select")
        for drop in dropdowns:
            if drop.is_displayed():
                try:
                    opts = drop.find_elements(By.TAG_NAME, "option")
                    # Prefer 0 values ​​according to your screenshot
                    priority_list = ["0", "0 year", "0 month", "0 years", "0 months", "No", "1"]
                    selection_done = False
                    
                    for target in priority_list:
                        for o in opts:
                            if o.text.strip().lower() == target.lower():
                                o.click()
                                selection_done = True
                                break
                        if selection_done: break
                    
                    if not selection_done and len(opts) > 1: opts[1].click()
                except: pass

        # 2. Handle Radio Buttons (Commute, Visa etc.)
        radios = driver.find_elements(By.CSS_SELECTOR, "fieldset, .fb-radio")
        for rd in radios:
            try:
                # Prefer 'Yes' so that the form moves forward
                yes_opt = rd.find_element(By.XPATH, ".//label[contains(translate(., 'YES', 'yes'), 'yes')]")
                driver.execute_script("arguments[0].click();", yes_opt)
            except:
                try:
                    # If not 'Yes', select the first option.
                    first_opt = rd.find_element(By.TAG_NAME, "label")
                    driver.execute_script("arguments[0].click();", first_opt)
                except: pass

        # 3. Handle Text and Number inputs
        all_inputs = driver.find_elements(By.CSS_SELECTOR, "input[type='text'], input[type='number'], textarea")
        for i in all_inputs:
            if i.is_displayed() and i.is_enabled() and i.get_attribute("value") == "":
                field_info = (i.get_attribute("id") + i.get_attribute("name") + (i.get_attribute("placeholder") or "")).lower()
                
                if any(x in field_info for x in ["city", "location"]):
                    i.send_keys("Pune, Maharashtra")
                    time.sleep(1)
                    i.send_keys(Keys.DOWN, Keys.ENTER)
                elif any(x in field_info for x in ["title", "headline", "experience"]):
                    i.send_keys("Fresher")
                elif "company" in field_info:
                    i.send_keys("N/A")
                else:
                    i.send_keys("0")

    except Exception as e:
        print(f" Form Update Error: {e}")

def process_application(company, role):
    """Manages the steps (Next, Review, Submit) of the application form"""
    global applied_count
    for _ in range(10):
        try:
            time.sleep(3)
            fill_form()
            
            # Finding buttons (Next, Review, Submit)
            buttons = driver.find_elements(By.XPATH, "//button[contains(., 'Next') or contains(., 'Review') or contains(., 'Submit')]")
            
            if not buttons: break

            for btn in buttons:
                if btn.is_displayed() and btn.is_enabled():
                    btn_text = btn.text.strip()
                    
                    if "Submit" in btn_text:
                        driver.execute_script("arguments[0].click();", btn)
                        print(f"🎉 Application submitted for {company}!")
                        time.sleep(4) 
                        try:
                            final_btns = driver.find_elements(By.XPATH, "//button[contains(., 'Done') or contains(., 'Not now')]")
                            if final_btns: driver.execute_script("arguments[0].click();", final_btns[0])
                        except: pass
                        applied_count += 1
                        send_telegram_msg(company, role, applied_count)
                        return True
                    else:
                        driver.execute_script("arguments[0].click();", btn)
                        time.sleep(2)
                        break
        except: break
    return False

def linkedin_bot():
    """Main function to run the bot"""
    global applied_count
    auto_login()

    while applied_count < DAILY_LIMIT:
        try:
            print(f"\n Current Progress: {applied_count}/{DAILY_LIMIT}")
            
            locations = "Pune%2C%20Mumbai"
            geo_ids = "104111361%2C106164952"
            search_url = f"https://www.linkedin.com/jobs/search/?f_AL=true&keywords=Java%20Developer%20Fresher&location={locations}&geoId={geo_ids}&f_TPR=r86400&f_E=2"
            
            driver.get(search_url)
            time.sleep(5)

            job_cards = driver.find_elements(By.CLASS_NAME, "job-card-container")
            if not job_cards:
                print(" No jobs found. Waiting...")
                time.sleep(60)
                continue
            
            for job in job_cards:
                if applied_count >= DAILY_LIMIT: return

                try:
                    driver.execute_script("arguments[0].scrollIntoView();", job)
                    job.click()
                    time.sleep(3)

                    role_title = driver.find_element(By.CLASS_NAME, "job-details-jobs-unified-top-card__job-title").text
                    company = driver.find_element(By.CLASS_NAME, "job-details-jobs-unified-top-card__company-name").text
                    
                    if not any(kw.lower() in role_title.lower() for kw in TARGET_ROLES):
                        print(f" Skip: {role_title} (Role not in list)")
                        continue

                    try:
                        subtitles = driver.find_elements(By.CLASS_NAME, "job-details-jobs-unified-top-card__subtitle-item")
                        app_text = next((s.text.lower() for s in subtitles if "applicant" in s.text.lower()), "")
                        if "over" in app_text or (re.findall(r'\d+', app_text) and int(re.findall(r'\d+', app_text)[0]) > 50):
                            print(f" Skip: {role_title} (High competition)")
                            continue
                    except: pass

                    try:
                        status = driver.find_element(By.CLASS_NAME, "artdeco-inline-feedback").text
                        if "Applied" in status: continue
                    except: pass

                    apply_btn = WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.CSS_SELECTOR, ".jobs-apply-button")))
                    print(f" Applying: {role_title} @ {company}")
                    apply_btn.click()
                    
                    if process_application(company, role_title):
                        human_like_scroll(random.randint(120, 180))

                except: continue
            
            print("\nCycle finished. 5-minute break...")
            human_like_scroll(180) 

        except Exception as e:
            print(f" Main Loop Error: {e}")
            time.sleep(30)

    print(f" Target reached! Total: {applied_count}")
    driver.quit()

if __name__ == "__main__":
    linkedin_bot()