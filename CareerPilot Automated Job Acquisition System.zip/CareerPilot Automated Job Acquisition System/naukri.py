import os
import time
import random
import requests
import re
from dotenv import load_dotenv
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

# 1. Load Configuration
load_dotenv()
N_EMAIL = os.getenv('NAUKRI_EMAIL')
N_PASS = os.getenv('NAUKRI_PASSWORD')
TELEGRAM_TOKEN = os.getenv('TELEGRAM_TOKEN')
TELEGRAM_CHAT_ID = os.getenv('TELEGRAM_CHAT_ID')

TARGET_ROLES = [
    # --- Backend & Java Roles ---
    "Java Developer", "Junior Java Developer", "Java Backend Developer", 
    "Core Java Developer", "Java Developer Fresher", "Java API Developer",
    "Java Backend Engineer", "Spring Boot Developer", "Spring Boot Developer Fresher",
    "Hibernate Developer", "Microservices Developer", "Java Spring Boot Developer",
    
    # --- Frontend & UI Roles (Based on your HTML5/CSS3 skills) ---
    "Frontend Developer", "Junior Frontend Developer", "UI Developer Fresher", 
    "Web Developer", "Junior Web Developer", "Web Developer Fresher", 
    "Frontend Developer HTML CSS", "Associate Frontend Engineer", "UI Designer Fresher",
    
    # --- Full Stack Roles ---
    "Java Full Stack Developer","Full-stack Developer", "Back End Developer","Software Development Engineer", "Full Stack Developer Fresher", "Junior Full Stack Developer",
    "Full Stack Java Developer", "Associate Software Engineer", "Software Engineer Fresher","Softwere developer enginner",
    
    # --- Database & Trainee Roles ---
    "SQL Developer", "MySQL Developer", "Trainee Software Engineer", 
    "Software Developer Trainee", "Graduate Engineer Trainee", "Entry Level Java Developer"
]
SKILL_VARIANTS = ["Java, Spring Boot, Hibernate, MySQL", "Java Developer, HTML, CSS, JavaScript", "Backend Developer, REST API, SQL"]

DAILY_LIMIT = 25
applied_count = 0

# Browser Setup
options = webdriver.ChromeOptions()
options.add_argument("--start-maximized")
options.add_experimental_option('excludeSwitches', ['enable-logging'])
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
wait = WebDriverWait(driver, 10)

def human_like_scroll(duration_seconds):
    print(f"🕵️ Human simulation: Scrolling for {duration_seconds//60} minutes...")
    end_time = time.time() + duration_seconds
    while time.time() < end_time:
        scroll_amount = random.randint(300, 800)
        direction = random.choice([scroll_amount, -scroll_amount])
        driver.execute_script(f"window.scrollBy(0, {direction});")
        time.sleep(random.randint(4, 10))

def send_telegram_msg(role, company, count):
    try:
        msg = f" *Naukri Applied! ({count}/{DAILY_LIMIT})*\n🏢 *Company:* {company}\n💼 *Role:* {role}\n🚀 CareerPilot is working!"
        url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
        payload = {"chat_id": TELEGRAM_CHAT_ID, "text": msg, "parse_mode": "Markdown"}
        requests.post(url, data=payload)
    except: pass

def naukri_login():
    try:
        driver.get("https://www.naukri.com/nlogin/login")
        wait.until(EC.presence_of_element_located((By.ID, "usernameField"))).send_keys(N_EMAIL)
        driver.find_element(By.ID, "passwordField").send_keys(N_PASS)
        driver.find_element(By.XPATH, "//button[@type='submit']").click()
        print(" Login Successful!")
        time.sleep(5)
    except Exception as e:
        print(f" Login Error: {e}")

def update_profile_skills_and_visibility():
    """Updated logic to handle layout changes in Naukri profile"""
    try:
        driver.get("https://www.naukri.com/mnjuser/profile")
        time.sleep(5)
        
        try:
            edit_btn = wait.until(EC.element_to_be_clickable((By.XPATH, "//span[text()='Key Skills']/following-sibling::span[contains(@class,'edit')]")))
        except:
            edit_btn = wait.until(EC.element_to_be_clickable((By.XPATH, "//div[@class='keySkills']//span[@class='edit']")))
            
        edit_btn.click()
        time.sleep(2)
        
        save_btn = wait.until(EC.element_to_be_clickable((By.ID, "submitSkill")))
        save_btn.click()
        print(" Profile visibility boosted!")
        time.sleep(3)
    except Exception as e: 
        print(f" Profile boost skipped: Layout changed or element not found.")
def fill_naukri_forms():
    responses = {
        "notice": "Immediate",
        "current ctc": "0.00",
        "expected ctc": "3.0",
        "experience": "0",
        "pune": "Yes",
        "mumbai": "Yes",
        "location": "Yes",
        "comfortable": "Yes",
        "graduate": "Yes",
        "full name": "Suraj Hanumant Takbhate"
    }

    # Let's loop 10 times so that the questions that come up one after the other are solved.
    for attempt in range(10):
        try:
            time.sleep(2) # Allow time for the next question to load.
            
            # 1. Get the text of the question
            questions = driver.find_elements(By.CSS_SELECTOR, ".msg-text, .chat-message-text, .question-text, .desc")
            if not questions:
                # If the questions are not visible, the form may have expired.
                break
            
            last_question = questions[-1].text.lower()
            print(f" Question {attempt+1}: {last_question}")

            #2. If experience is too much, skip it.
            if any(word in last_question for word in ["4 years", "5 years", "3 years"]):
                print(" High Experience Job! Skipping...")
                return "SKIP"

            # 3. Clicking Radio Buttons/Options (e.g. Yes/No, Immediate)
            options = driver.find_elements(By.CSS_SELECTOR, ".radio-option, .tap-chip, .suggested-option, li.radio-option")
            option_clicked = False
            for opt in options:
                opt_text = opt.text.lower()
                if any(res_key in opt_text for res_key in ["yes", "immediate", "0", "bachelors", "graduate"]):
                    driver.execute_script("arguments[0].click();", opt)
                    print(f" Selected: {opt_text}")
                    option_clicked = True
                    time.sleep(1)
                    break

            # 4. If there is no option, search for Text Input.
            if not option_clicked:
                inputs = driver.find_elements(By.CSS_SELECTOR, "input#chat-input, input[type='text'], div[contenteditable='true']")
                for inp in inputs:
                    if inp.is_displayed():
                        for key, val in responses.items():
                            if key in last_question:
                                inp.send_keys(val)
                                inp.send_keys(Keys.ENTER)
                                print(f" Typed: {val}")
                                break
                        time.sleep(1)

        
            
            try:
                footer_btns = driver.find_elements(By.XPATH, "//button[contains(text(),'Save') or contains(text(),'Submit') or contains(text(),'Next') or @class='save-button']")
                for b in footer_btns:
                    if b.is_displayed() and b.is_enabled():
                        driver.execute_script("arguments[0].click();", b)
                        print(" Clicked Save/Next")
                        time.sleep(2)
                        break
            except:
                pass

            # If you get an 'Application Submitted' or 'Success' message, exit.
            if "success" in driver.page_source.lower() or "applied" in driver.page_source.lower():
                print(" Application successfully completed!")
                break

        except Exception as e:
            print(f" Screener Loop Error: {e}")
            break


applied_job_titles = set()# To store the names of jobs handled today
# ----------------------------------------------------

def apply_to_jobs():
    global applied_count
    for role in TARGET_ROLES:
        if applied_count >= DAILY_LIMIT: break
        
        print(f"\n Searching for: {role}")
        # The filter for experience=0 and '0-0' years in the search URL has been tightened.
        search_url = f"https://www.naukri.com/{role.replace(' ', '-').lower()}-jobs-in-pune-mumbai?experience=0&jobAge=1&k={role.replace(' ', '%20')}&experienceLimit=0"
        driver.get(search_url)
        time.sleep(5)

        job_cards = driver.find_elements(By.CLASS_NAME, "srp-jobtuple-wrapper")
        
        for job in job_cards:
            if applied_count >= DAILY_LIMIT: break
            
            try:
                role_name = job.find_element(By.CLASS_NAME, "title").text
                company_name = job.find_element(By.CLASS_NAME, "comp-name").text
                job_id = f"{role_name}-{company_name}" # Unique ID created
                # --- This is an important change: Skip if you have already seen the job ---
                if job_id in applied_job_titles:
                    continue
                applied_job_titles.add(job_id)
                # ---------------------------------------------------------

               # 1. Verifying experience (If the card says '5-10 Yrs', skip it already)
                try:
                    exp_text = job.find_element(By.CLASS_NAME, "expwdth").text
                    if any(num in exp_text for num in ["3", "4", "5", "6", "7"]):
                        print(f" Skip: High Experience Required ({exp_text}) for {company_name}")
                        continue
                except: pass

                
                try:
                    stats_element = job.find_elements(By.CLASS_NAME, "stats")
                    if stats_element:
                        applicants = re.findall(r'\d+', stats_element[0].text)
                        if applicants and int(applicants[0]) > 60:
                            print(f" Skip: High competition ({applicants[0]} applicants).")
                            continue
                except: pass

                
                job.find_element(By.CLASS_NAME, "title").click()
                driver.switch_to.window(driver.window_handles[-1])
                time.sleep(3)

                try:
                    # Check if there is an 'Apply' button on the screen
                    apply_btn = wait.until(EC.element_to_be_clickable((By.ID, "apply-button")))
                    apply_btn.click()
                    time.sleep(3)
                    
                    form_status = fill_naukri_forms()
                    
                    if form_status == "SKIP":
                        print(f" Skipping {company_name} due to high exp questions.")
                    else:
                        print(f" Applied: {role_name} at {company_name}")
                        applied_count += 1
                        send_telegram_msg(role_name, company_name, applied_count)
                    
                    time.sleep(random.randint(50, 180))
                    
                except:
                    print(f" Skip: External Site or Already Applied.")

                driver.close()
                driver.switch_to.window(driver.window_handles[0])
                
            except Exception as e:
                # If an error occurs, return to the original window and move to the next card
                if len(driver.window_handles) > 1:
                    driver.close()
                    driver.switch_to.window(driver.window_handles[0])
                continue


            
def main():
    naukri_login()
    update_profile_skills_and_visibility()
    apply_to_jobs()
    print(f"🏁 Final Total Applied: {applied_count}")
    driver.quit()

if __name__ == "__main__":
    main()